/** Yet another example for assignments 
 *
 *  @author  Manfred Kerber
 *  @version 2014-09-27
 */

public class Var3 { 
    public static void main(String[] args) {

       int x;

       System.out.print("System.out.println(x = 3;);     ==> ");  x = 3; System.out.println();
       System.out.print("System.out.println(x);          ==> ");  System.out.println(x);
       System.out.println();

       System.out.print("System.out.println(x = x+8;);   ==> ");  x = x+8; System.out.println();
       System.out.print("System.out.println(x);          ==> ");  System.out.println(x);
       System.out.println();
   }
}
